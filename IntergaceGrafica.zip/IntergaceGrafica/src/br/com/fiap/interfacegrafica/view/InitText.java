package br.com.fiap.interfacegrafica.view;

import java.awt.Color;

import javax.swing.JTextField;
public class InitText extends JTextField{

		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public InitText() {
			super(20);
			init();
		}

		private void init() {
			this.setForeground(new Color(50,50,50));
			this.setBackground(Color.white);
			this.setBorder(BorderFactory.create());
		}
}
