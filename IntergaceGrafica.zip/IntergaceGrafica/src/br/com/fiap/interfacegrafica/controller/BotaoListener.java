package br.com.fiap.interfacegrafica.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import br.com.fiap.interfacegrafica.dao.FilmeDao;
import br.com.fiap.interfacegrafica.model.Filme;

// MVC

public class BotaoListener implements ActionListener {
	
	private br.com.fiap.interfacegrafica.view.Janela view;
	private FilmeDao dao = new FilmeDao();

	public BotaoListener(br.com.fiap.interfacegrafica.view.Janela view) {
		this.view = view;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		Filme produto = new Filme();
		produto.setTitulo(view.getTxtTitulo());
		produto.setGenero(view.getTxtGenero());
		produto.setSinopse(view.getTxtSinopse());
		produto.setOndeAssistir(view.getTxtOndeAssistir());
		produto.setAssitido(view.getTxtAssitido());
		produto.setAvaliacao(view.getTxtAvaliacao());
		
		dao.inserir(produto);
		
		view.carregarDados();
		
		List<Filme> lista = dao.listarTodos();
		lista.forEach(System.out::println);
	}
	
}
