package br.com.fiap.interfacegrafica;

import br.com.fiap.interfacegrafica.view.Janela;

public class App {
	
	public static void main(String[] args) {
		new Janela().init();
	}
}
